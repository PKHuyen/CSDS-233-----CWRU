import java.util.*;
//Queue (Push at rear, pop at front) that act like stack (Pop and push at top)
public class CustomQStack {
    //The field that store information of theQueue that we will perfome in
    private static Queue<Integer> theQueue = new LinkedList<Integer>();
    
    /** Constructor of the class */
    public CustomQStack(Queue<Integer> queue) {
       theQueue = queue; 
    }
   
    /** Helper method to return the elements in theQueue */
    public static Queue<Integer> getQueue() {
        return theQueue;
    }
    
    /** Push method that add the item to the rear of queue (on top of the stack) */
    public static void push(int item) {
        theQueue.add(item);
    }
    
    /** Pop method that remove the item at the front of the rear (on top of the stack) */
    public static int pop() {
        int theSize = theQueue.size();
        if(theQueue.isEmpty()) return -1;
        for (int i = 0; i < theSize - 1; i++) { //last item is kept to be the first item
            int x = theQueue.remove();
            theQueue.add(x);
        }
        int x = theQueue.remove();
        return x;
    }
    
    /** Empty method to check if theQueue is empty */
    public static boolean empty() {
        return theQueue.isEmpty();
    }
    
    /** Main method to run the program */
    public static void main (String[] args) {
        Queue<Integer> queue = new LinkedList<Integer>();
        queue.add(5);
        queue.add(6);
        queue.add(7);
        queue.add(8);
        queue.add(9);
        CustomQStack s = new CustomQStack(queue);
        System.out.println(s.getQueue()); // expect to have return [5, 6, 7, 8, 9]
        int x = s.pop();
        System.out.println(x); // expect to have return 9
        x = s.pop(); 
        System.out.println(x); // expect to have return 8
        System.out.println(s.empty()); //return false
        s.push(1);
        System.out.println(s.getQueue()); // expect to have return [5, 6, 7, 1]
        x = s.pop();
        System.out.println(x); // expect to have return 1
    }
}
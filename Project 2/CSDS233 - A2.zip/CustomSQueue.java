import java.util.*;
//Stack but act like Queue (push at top, pop at bottom)
public class CustomSQueue {
    private static Stack<Integer> stack1 = new Stack<Integer>(); //the returned stack
    private static Stack<Integer> stack2 = new Stack<Integer>(); //helps stack1 performs appropriately
    
    /** Constructor, store the newly created stack as stack 1 */
    public CustomSQueue(Stack<Integer> s1, Stack<Integer> s2) {
        this.stack1 = s1;
        this.stack2 = s2;
    }
    
    /** Helper method that return the stack */
    public static Stack<Integer> getStack() {
       return stack1;
    }
    
    /** Add method to add item into the top of the stack */
    public static Stack<Integer> add(int item) {
        //always add item to stack1 even if stack1 is empty to update stack1
        stack1.push(item);
        return stack1;
    }
    
    /** Poll method to remove the item at the bottom of the stack */
    public static int poll() {
        //x is to find the item at the top of the stack
        int x = 0; 
        
        // When stack1 is not empty, moves all element from stack1 to stack2 from top to bottom so that stack2
        // will have inverted list of element
        while(!stack1.isEmpty()) {
            stack2.push(stack1.pop());
        }
        //Therefore, x is at the top of the stack2
        x = stack2.peek();
        
        //Remove x
        stack2.pop();
        
        //When stack2 is not empty, moves all element from stack2 to stack1 from top to bottom so that stack1 
        //will have inverted list of element without x
        while(!stack2.isEmpty()) stack1.push(stack2.pop());
        
        return x;
    }
    
    /** Main method to run the program */
    public static void main (String[] args) {
       Stack<Integer> st1 = new Stack<Integer>();
       Stack<Integer> st2 = new Stack<Integer>();
       st1.push(5);
       st1.push(6);
       st1.push(7);
       st1.push(8);
       st1.push(9);
       CustomSQueue s= new CustomSQueue (st1, st2);
       int x = s.poll();
       System.out.println(x); //expect to return 5
       x = s.poll();
       System.out.println(x); //expect to return 6
       s.add(2);
       System.out.println(s.getStack()); //expect to return [7, 8, 9, 2]
    }
}
import java.util.*;
public class HW2CSDS233 {
    // The field that remember the head of the Linkedlist
    private static Node head = null;
    // The field that remember the size of the LinkedList
    private static int size = 0;
    
    /** The inner class Node to define Node */
    public static class Node {
        int element; //the data in each node called element
        Node next; // the next node of each current node
        
        /** Constructor of Node class to define Node */
        public Node (int element, Node next) {
            this.element = element;
            this.next = next;
        }
        
        /** Helper method to return the element of each node */
        public int getElement() {
            return element;
        }
        
        /** Helper method to change the element of each node */
        public void setElement(int element) {
            this.element = element;
        }
        
        /** Helper method to return the next node of current node */
        public Node getNext() {
            return next;
        }
        
        /** Helper method to change the pointer to next node */
        public void setNext(Node next) {
            this.next = next;
        }
    }
    
    /** Helper method to return head */
    public static Node getFirstNode() {
        return head;
    }

    /** Helper method to add Node into the list */
    public static void addNode(Node n) {
        if (head == null) { //if list is empty, head is n
            head = n;
            head.setNext(null);
        }
        Node ptr = head;
        while (ptr.getNext() != null) { //else find the last node then add n as next node of last node of the list
            ptr = ptr.getNext();
        }
        ptr.setNext(n);
        n.setNext(null);
    }
    
    /** Helper method to return size of the list */
    public static int size() {
        return size;
    }
    
    /** reverse() method to change the pointer of each node to opposite direction */
    public void reverse() {
        Node previousNode = null; 
        Node currentNode = head;
        Node nextNode = null;
            while (currentNode.getNext() != null) { //Traversing until there's no more element
                nextNode = currentNode.getNext(); // save reference of nextNode
                currentNode.setNext(previousNode); // Make currentNode points to previousNode instead of nextNode
                previousNode = currentNode; //Advance previousNode to currentNode
                currentNode = nextNode; //Advancee currentNode to nextNode
            }
            head = currentNode; //Change the head of the list
            head.next = previousNode;
    }
    
    /** Main method to run the program */
    public static void main (String[] args) {
        HW2CSDS233 s = new HW2CSDS233();
        Node n1 = new Node(5, null);
        Node n2 = new Node(6, null);
        Node n3 = new Node(7, null);
        Node n4 = new Node(8, null);
        Node n5 = new Node(9, null);
        s.addNode(n1);
        s.addNode(n2);
        s.addNode(n3);
        s.addNode(n4);
        s.addNode(n5);
        s.reverse(); 
        System.out.println(s.getFirstNode().getElement() + " " + s.getFirstNode().getNext().getElement() + " " + 
                           s.getFirstNode().getNext().getNext().getElement() + " " + 
                           s.getFirstNode().getNext().getNext().getNext().getElement() + " " + 
                           s.getFirstNode().getNext().getNext().getNext().getNext().getElement());
    }
}
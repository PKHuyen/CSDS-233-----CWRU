import java.util.*;
public class BST_Class {
    //The field that rememeber the root of the BST
    private Node root = null;
    //The field that rememeber the size of the BST
    private int size = 0;

    /** The Node class that can help creating a new node 
     * and return the key, the left Node, the right Node
     * of the current Node
     */
    public class Node {
        int key;
        Node left;
        Node right;

        /**Constructor of the Node class */
        public Node (int key) {
            this.key = key;
        }

        /** Helper method to return the key of the Node */
        public int getKey() {
            return key;
        }

        /** Helper method to return the left node of the Node */
        public Node getLeft() {
            return left;
        }
        /** Helper method to return the right node of the Node */
        public Node getRight() {
            return right;
        }
    }

    /** Constructor BST_Class */
    public BST_Class() {
        root = null;
    }

    /** Helper method to return the root of the tree */
    public Node getRoot() {
        return root;
    }

    /** Helper method to return the size of the tree */
    public int getSize() {
        return size;
    }

    /** Helper method of the search() to traverse the tree */
    public Node searchTree(Node root, int key) {
        //when the tree is empty,
        if (root == null) return null;
        //if the key to find is in the root
        else if (key == root.key) return root;
        //if the key is smaller than the root, then the node must be on the left subtree
        else if (key < root.key) return searchTree(root.left, key);
        //if the key is larger than the root, then the node must be on the right tree
        else return searchTree(root.right, key);
    }
    
     /** Helper method deleteNode() of the deleteKey() method that help traverse and reconnect the tree */
     public Node deleteNode(Node root, int key) {
    if (root == null) return null;
    if (key < root.key) root.left = deleteNode(root.getLeft(), key);
    else if (key > root.key) root.right = deleteNode(root.getRight(), key);
    else {
            if(root.left == null) return root.right;
           else if (root.right == null) return root.left;
           root.key = minValue(root.right); //smallest key in the right subtree
         root.right = deleteNode(root.right, root.key);
        }
     return root;
    }   

    /** Insert method that insert a new node that contain the key to the tree */
    public void insert(int key) {   
        Node parent = null;
        Node trav = root;
        //while it can still be traverse through the tree, continue the loop. Make the current trav to parents, 
        // and trav set to new Left or Right node of the parent depend on its key
        while (trav != null) {
            parent = trav; 
            if (key < trav.getKey()) trav = trav.getLeft();
            else trav = trav.getRight();
            size++;
        }
        // if the tree is empty, make the root as the new node that contain key
        if (parent == null) root = new Node (key);
        //after found the place need to insert, depends on the key of parents, add the node contains key left or right node of the parent
        else if (key < parent.key) parent.left = new Node(key);
        else parent.right = new Node(key);
        size++;
    }

    /** postOrder() method that rearrange the key into postOrder traversal */
    public void postOrder(Node node) {
        if(node.getLeft() != null) postOrder(node.getLeft()); 
        if (node.getRight() != null) postOrder(node.getRight());
        System.out.print(node.getKey() + " ");
    }    

    /** inOrder() method that rearrange the key into inOrder traversal */
    public void inOrder(Node node) {
        if (node.getLeft() != null) inOrder(node.getLeft());
        System.out.print(node.getKey() + " ");
        if (node.getRight() != null) inOrder(node.getRight());
    }

    /** preeOrder() method that rearrange the key into preOrder traversal */
    public void preOrder(Node node) {
        System.out.print(node.getKey() + " ");
        if(node.getLeft() != null) preOrder(node.getLeft());
        if (node.getRight() != null) preOrder(node.getRight());
    }

    /** search() method to find if the given key exists in the tree */
    public boolean search(int key) {
        if (root == null) return false;
        else return root == searchTree(root, key);
    }

    /** minValue() method to return the smallest value of the tree */
    public  int minValue(Node root) {
        Node current = root;
        if (root == null) throw new RuntimeException("No tree available");
        while (current.getLeft() != null) {
            current = current.getLeft();
        }
        return (current.getKey());
    }

    /** deleteKey() method to delete the node from the tree */
    public void deleteKey(int key) {
        if (root == null) throw new RuntimeException("No tree available");
        else root = deleteNode(root, key);
    }

    /** Wrapper of Post Order Traversal */
    public void postOrderTraversal() {
        if (root == null) throw new RuntimeException("No tree available");
        postOrder(root);
    }

    /** Wrapper of In Order Traversal */
    public void inOrderTraversal() {
        if (root == null) throw new RuntimeException("No tree available");
        else inOrder(root);
    }

    /** Wrapper of Pre Order Traversal */
    public void preOrderTraversal() {
        if (root == null) throw new RuntimeException("No tree available");
        preOrder(root);
    }

    /** Main method that run the program */
    public static void main (String[] args) {
        BST_Class s = new BST_Class();
        s.insert(90);
        s.insert(12);
        s.insert(10);
        s.insert(7);
        s.insert(45);
        s.insert(50);

        System.out.println("The BST Created with input data (Left - Root - Right)");
        s.inOrderTraversal();
        System.out.println(" ");

        s.deleteKey(12);
        System.out.println("BST after delete 12 (leaf node) ");
        s.inOrderTraversal();
        System.out.println(" ");

        s.deleteKey(90);
        System.out.println("BST after delete 90 (node with 1 child) ");
        s.inOrderTraversal();
        System.out.println(" ");
        
        s.deleteKey(45);
        System.out.println("BST after delete 45 (Node with two children) ");
        s.inOrderTraversal();
        System.out.println(" ");

        System.out.println("Key 50 found in BST: " +  s.search(50));

        System.out.println("Key 12 found in BST: " +  s.search(12));

        BST_Class s1 = new BST_Class();
        s1.root = s1.new Node(45);
        s1.root.left = s1.new Node(10);
        s1.root.right = s1.new Node(90);
        s1.root.left.left = s1.new Node(7);
        s1.root.left.right = s1.new Node (12);
        System.out.println("BST => PreOrder Traversal");
        s1.preOrderTraversal();
        System.out.println(" ");

        System.out.println("BST => InOrder Traversal");
        s1.inOrderTraversal();
        System.out.println(" ");

        System.out.println("BST => PostOrder Traversal");
        s1.postOrderTraversal();
        System.out.println(" ");
    }
}
import java.util.*;
public class Graph{
    //The field that contain list
    private LinkedList<Node> list;

    
    /**Node Class */
    public class Node {
        public String name; //The name of the node
        public boolean visited; //Check if visited
        public LinkedList<Node> neighbors; //Refer to all neighbors of current Node
        public Node prev; //Refer to previous node of the current node (parent)
        public int cost;

        public Node (String name) {
            this.name = name;
            this.visited = false;
            this.neighbors = new LinkedList<>();
            this.prev = null;
            this.cost = 0;
        }
    }

    /** Constructor */
    public Graph() {
        list = new LinkedList<>();
    }

    /** Helper method to get the list */
    public LinkedList<Node> getList() {
        return this.list;
    }

    /** Helper class to find the index of the node that have String name */
    public int getIndex(String name) { 
        int i = 0;
        //if the name exist, return the index of the node that have input name
        while (i < list.size()) {
            if (list.get(i).name.equalsIgnoreCase(name)) return i; 
            i++;
        }
        return -1; //if name not exist
    }

    /** Add node to the current list */
    public boolean addNode(String name) {
        if (name == null) throw new NullPointerException(); //if name is not input
        else if (getIndex(name) != -1) return false; //already in the list
        else { 
            int i = 0;
            if (list.size() == 0) { //if this is the first node, add name 
                list.add(0, new Node(name));
                return true;
            }

            else { //while adding new edge, add it alphabetically 
             
                if (list.get(0).name.compareTo(name) >= 0) { //if all nodes is larger than input name, then name be the first node
                    list.add(0, new Node (name));
                    return true;
                }

                while (i < list.size()) {
                    if (list.get(i).name.compareTo(name) < 0) i++; //
                    else { //add if name is now larger or equal current node
                        list.add(i, new Node(name));
                        return true;
                    }
                }
                list.add(new Node(name)); //add to the last of list all nodes has passed
                return true;
            }
        } 
    }

    /** Add multiple nodes into the list. */
    public boolean addNodes(String[] names) { 
        boolean visited = true;
        for (int i = 0; i < names.length; i++) { //Each name in name array is called in addNode()
            visited = addNode(names[i]);
        }
        return visited;
    }

    /** Add edge between node. Change the neighbor order list alphabetically */
    public boolean addEdge (String from, String to) {
        if (from == null || to == null) throw new NullPointerException(); 
        else if (from.equals(to) || getIndex(from) == -1 || getIndex(to) == -1) return false; //the edge cannot exist if from or to not in list
        else { //list must contain both nodes
            //Update information for from node (neighbors[], numNeighbor)
            int fromIndex = getIndex(from);
            int toIndex = getIndex(to);
            Node fromNode = list.get(fromIndex);
            Node toNode = list.get(toIndex);

            if (list.get(fromIndex).neighbors.size() == 0) {
                list.get(fromIndex).neighbors.add(toNode);
                list.get(toIndex).neighbors.add(fromNode);
                return true;
            }

            else {
                //Update the neighbor of the "from" node
                int i = 0;
                int added = 0;
                while (i < list.get(fromIndex).neighbors.size()) {
                    if (list.get(fromIndex).neighbors.get(i).name.compareTo(to) < 0) { //alphabetically
                        i++;
                    }
                    else {
                        list.get(fromIndex).neighbors.add(i, toNode);
                        added = 1;
                        break;
                   }
                } 
                if (added != 1) list.get(fromIndex).neighbors.add(toNode);

                //Update the neighbor of the "to" node
                i = 0;
                added = 0;
                while (i < list.get(toIndex).neighbors.size()) {
                    if (list.get(toIndex).neighbors.get(i).name.compareTo(from) < 0) { //alphabetically
                        i++;
                    }
                    else {
                        list.get(toIndex).neighbors.add(i, fromNode);
                        added = 1;
                        break;
                   }
                }
                if (added != 1) list.get(toIndex).neighbors.add(fromNode);
                return true;
            }
        }
    }

    /** addEdges() method to add multiple edge from "from" node to multiple "to" node in toList array */
    public boolean addEdges(String from, String[] toList) {
        boolean visited = true;
        for (int i = 0; i < toList.length; i++) { 
            visited = addEdge(from, toList[i]);
        }
        return visited;
    }

    /** Remove node from the list, edit the neighbor order list */
    public boolean removeNode (String name) {
        if (name == null) throw new NullPointerException();
        else if (getIndex(name) == -1) return false;
        else { 
            int index = getIndex(name);
            //update the neighbors[] of which associate with this node
            //from list.get(index).neighbors[i], search each of the node, find name in their neighbor, delete
            for (int i = 0; i <list.get(index).neighbors.size(); i++) {
                list.get(i).neighbors.remove(list.get(index));
            }
            //update the list without this node
            list.remove(index);
            return true;
        }
    }

    /** RemoveNodes() that remove multiple ndoes from nodeList array */
    public boolean removeNodes (String[] nodeList) {
        boolean visited = true;
        for (int i = 0; i < nodeList.length; i++) {
            visited = removeNode(nodeList[i]);
        }
        return visited;
    }

    /**Show the list as adjacency list */
    public void printGraph() {
        if (list == null) System.out.println("The List is empty");
        else {
            int i = 0;
            while (i < list.size()) {
                System.out.print(list.get(i).name + " -> "); //print name 
                //now access to the neighbors. default is alphabetically
                for (int j = 0; j < list.get(i).neighbors.size(); j++) System.out.print(list.get(i).neighbors.get(j).name + ((j == list.get(i).neighbors.size() - 1) ? "" : " -> "));
                System.out.println();
                i++;
            }
        }
    }

    /** Depth first Search */
    public String[] DFS (String from, String to, String neighborOrder) {
        if (from == null || to == null || neighborOrder.equalsIgnoreCase("alphabeticalOrder") && neighborOrder.equals("reverseOrder")) return null;
        else if (getIndex(from) == -1 || getIndex(to) == -1) return null;
        else {
            LinkedList<String> path  = new LinkedList<>(); //The path that DFS will go 
            myDFS(from, to, neighborOrder, path);
            String[] return_path = new String[path.size()]; 
            int i = 0;
            if (neighborOrder.equals("alphabeticalOrder")) { //Make the path go alphabetically
                for (int j = path.size() - 1; j >= 0; j--) { 
                    return_path[j] = path.get(i);
                    i++;
               }
            }
            else { //Make the path go reverse
                while (i < path.size()) {
                   return_path[i] = path.get(i);
                    i++;
                }
            }
            return return_path;
       }
    }

    /**Helper method for DFS to update the path. At the current node, we recursively check which neighbor can go to "to" node
     * If neighbor return true, then we determine that the path that have neighbor must be exist to go to "to"
     * Recursive from "to" node to "from" node
     */
    private boolean myDFS(String from, String to, String neighborOrder, LinkedList<String> path) {
        int fromIndex = getIndex(from);
        if (from == null || to == null || (!neighborOrder.equals("alphabeticalOrder") && !neighborOrder.equals("reverseOrder"))) return false;
        else if (getIndex(from) == -1 || getIndex(to) == -1) return false;
        else {
            //Check if from is to. Then we found the destination, add to path
            if (from.equals(to)) {
                list.get(getIndex(from)).visited = true; 
                path.add(from);
                return true;
            }

            //check if from can go to to by going to ask from.neighbor
            list.get(getIndex(from)).visited = true;
            for (Node neighbor : list.get(fromIndex).neighbors) {
                if (neighbor.visited == false) {
                    if (myDFS(neighbor.name, to, neighborOrder, path) == true) { //neighbor == to
                        path.add(from);
                        return true;
                    }
                }
            }
            return false;
        }
    }

    /** Breadth First Search */
    public String[] BFS(String from, String to, String neighborOrder) {

        //reset visited for every node in list
        for (int i = 0; i < list.size(); i++) list.get(i).visited = false; 

        if (from == null || to == null || (!neighborOrder.equalsIgnoreCase("alphabeticalOrder") && !neighborOrder.equalsIgnoreCase("reverseOrder"))) return null;
        else if (getIndex(from) == -1 || getIndex(to) == -1) return null;
        else {
            Queue<Node> queue = new LinkedList<Node>();
            LinkedList<String> return_string = new LinkedList<>();
            //if from not equal to, add source first, then while (queue is not empty), keep updatingt the previous node (parent node) of the neighbor to be current node
            if (!from.equals(to)) { 
                queue.add(list.get(getIndex(from))); //add source
                //If the queue is empty, have to check to add Node into Queue to keep track of the path
                while (!queue.isEmpty()) {
                    Node parent = queue.poll(); //this is the parent of the current node (neighbors of "from")
                    parent.visited = true; 
                    for (Node neighbor : parent.neighbors) { //for every neighbor, add to queue, set to visited, then update the previous node (parent node)
                        if (neighbor.visited == false) {
                            neighbor.visited = true;
                            neighbor.prev = parent;
                            queue.add(neighbor);
                        }
                    }
                    if (parent.name.equals(to)) { 
                        return_string.add(to);
                            while (parent.prev != null) {
                                parent = parent.prev;
                                return_string.add(parent.name);
                            }
                            if (neighborOrder.equalsIgnoreCase("alphabeticalOrder")) { //alphabetically
                                Collections.reverse(return_string);
                            }
                            return return_string.toArray(new String[queue.size()]);
                    }
                }
                return null;
            }
            else {
                return_string.add(from);
                return return_string.toArray(new String[1]);
            }
        }
    }

    /** Dijstrak algorithm to find shortest path */
    public String[] shortestPath(String from, String to) {
        //Since this is unweighted Graph, Dijstrak algorithm is Breadth First Search.
        return BFS(from, to, "alphabeticalOrder");
    }

    /** Run the program */
    public static void main (String[] args) {
        Graph g = new Graph();
        g.addNode("A");        
        g.addNode("B");
        g.addNode("C");
        g.addNode("D");
        //done

        g.addEdge("A" , "B");
        g.addEdge("B" , "C");
        g.addEdge("C" , "D");
        g.addEdge("D" , "A");
        g.printGraph();

        System.out.println("DFS: " + Arrays.toString(g.DFS("A", "C", "alphabeticalOrder")));
        System.out.println("BFS: " + Arrays.toString(g.BFS("A", "C", "alphabeticalOrder")));
        System.out.println("Shortest Path: " + Arrays.toString(g.shortestPath("A", "D")));
    }
}
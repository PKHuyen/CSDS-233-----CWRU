/** Note:
 * The Answer for Second Shortest Path in this extra credit part can be found in 
 * secondShortestPath() method 
 * Please take a look there.
 * Thank you
 */
import java.util.*;
public class WeightedGraph {
    //The field that remember the adjacency list
    LinkedList<Node> list = new LinkedList<>();

    /**Node Class */
    public class Node {
        public String name; //The name of the node
        public boolean visited; //Check if visited
        public LinkedList<Node> neighbors; //Refer to all neighbors of current Node
        public Node prev; //Refer to previous node of the current node (parent)
        public int cost;

        public Node (String name) {
            this.name = name;
            this.visited = false;
            this.neighbors = new LinkedList<>();
            this.prev = null;
            this.cost = 0;
        }
    }

    /** addWeightedEdge to the graph */
    public boolean addWeightedEdge(String from, String to, int weight) {
        if (from == null || to == null) throw new NullPointerException();
        else if (from.equals(to) || weight <= 0) return false;
        else {
            //Update neighbors, parents, cost.
            return true;
        }
    }

    /** addWeightedEDges to the graph */
    public boolean addWeightedEdges (String from, String[] toList, int[] weight) {
        if (from == null || toList == null) throw new NullPointerException();
        for (int i = 0; i < toList.length; i++) {
            if (from.equals(toList[i]) || weight[i] <= 0) return false;
            else {
                addWeightedEdge(from, toList[i], weight[i]);
                return true;
            }
        }
        return true;
    }
    
    /** Print graph */
    public void printWeightedGraph() {
        String[] graph = new String[list.size()];
        for (int i = 0; i < graph.length; i++) graph[i] = list.get(i).name;
        Arrays.sort(graph);

        // Print the graph here
    }

    /** Using Dijkstra algorithm to find shortest path. */
    public String[] shortestPath(String from, String to) {
        if (from == null || to == null) throw new NullPointerException();
        else {
            String[] result = new String[list.size()];
            //Dijstrka algorithm
            return result;
        }
    }
    /** Second shortest path of the graph */
    public String[] secondShortestPath(String from, String to) {
        if (from == null || to == null) throw new NullPointerException();
        else {
            String[] result = new String[list.size()];

            /** Written Theory
             * - The algorith to be used: Dijkstra's algorithm
             
             * - Use the algorithm on all edges of Vertices exists on the Graph
             
             * - If there's no path from "from" to "to" at some point while looking, go to the next edge (of the same vertices to check)
             
             * - Else, if it's connected, the applied Dijkstra's algorithm to retrieve to the path. At the same time, remember the current cost on this path
             
             * - Compare the current cost to previous cost that we (may) have, if it's shorter, update the current cost and current path,
             but still need to remember the cost and path have just been replaced ("second"). Else do nothing

             * - Before exist the for loop, we have all possible path to go, the second shortest path is remembered as "second" variables.
             */

            return result;
        }
    }

    public static void main (String[] args) {
        WeightedGraph g = new WeightedGraph();
    }
}

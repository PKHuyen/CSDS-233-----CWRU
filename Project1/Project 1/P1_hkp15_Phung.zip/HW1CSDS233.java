import java.util.*;
public class HW1CSDS233 {
    
    //The field that store the nth number in Fibonacci List
    private static int n = 0;
    
    //The field that store the list of the Fibonacci List.
    private static int[] theList = null;
    
    /** The main method that run the program */
    public static void main(String[] args) {
        n = Integer.parseInt(args[0]);
        if (n <= 0) {
            throw new RuntimeException();
        }
        fibonacciIteration(n);
        theList = fibonacciList(n);
    }
    
    /** The method that return the Fibonacci List */
    public static int[] getFibonacciList() {
        return theList;
    }
    
    /** Iteration method of Fibonacchi 
      * Big o Notation: O(N) => have smaller time complexity
      */
    public static int fibonacciIteration(int n) {
        // the temporary array that store the fibonacchi numbers then later store to theList field
        int num1 = 0;
        int num2 = 1;
        
        //the nth number of the fibonacciList 
        int result = 0; 
        
        //if the input is to find the 1st number
        if (n == 1) return 0; 
        
        // if the input is to find the 2nd number
        else if (n == 2) return 1; 

        // if the input is to find nth number that n > 2
        if (n > 2) {
            for (int i = 2; i < n; i++) {
               result = num1 + num2;
               num1 = num2;
               num2 = result;
            }
        }
        return result;
    }
    
    /** Recursion method of Fibonacci 
      * Big O notation: O(2^n) 
      */
    public static int fibonacciRecursion(int n) {
        if (n == 1) return 0;
        else if (n == 2) return 1;
        else return fibonacciRecursion(n - 2) + fibonacciRecursion(n - 1);    
    }
    
    /**Add all the Fibonacci number until nth to the List 
      * Because fibonacciIteration has smaller running time, use this method to add to theList 
      */
    public static int[] fibonacciList(int n) {
        int[] tempList = new int[n];
        for (int index = 0; index < n; index++) {
            tempList[index] = fibonacciIteration(index + 1);
        }
        theList = tempList;
        return tempList;
    }
    
    /** Add new number (including ones that not a fibonacchi number) to the list */
    public static void add(int item) {
        int index = 0;
        n = n + 1; // update the length of the List
        int[] tempList = new int[n];
        //Loop when find from index 0 until find the last number to added item
        while(index < n - 1 && theList[index] < item) {
            tempList[index] = theList[index];
            index++;
        }
        tempList[index] = item; //add item to the list
        index++;
        //Continue to add the rest of the number from the list to new list
        while (index < n) {
            tempList[index] = theList[index - 1];
            index++;
        }
        theList = tempList;
    }
    
    /** Remove the desired number into Fibonacci List If it is able to move, the positions that do not have element showed 0 */ 
    public static void remove(int item) {
        int index = 0; // index of theList
        int i = 0; //index of tempList
        int[] tempList = new int[n]; // a temporary list to make changes to the list
        int temp_n = n; //temporary total number in the list
        
        /** If contains then have to make sure that the index should be lower than the length of fibonacciList (n). 
          * If item != theList => import element from theList to tempList (before found)
          * Found then remove, ignore the index that = item
          * After found, current in templist = theList.
          */ 
        if (ifContains(item) == true) {
            while (index < n) {
                //If the list is not equals to the item, move theList to tempList
                if (theList[index] != item) {
                    tempList[i] = theList[index];                    
                    index++;
                    i++;
                }
                //theList[index] = item
                else {
                    while(index < n && theList[index] == item) {
                        temp_n--;
                        index++;
                    }
                }  
            }
            n = temp_n;
            theList = tempList;
        }
    }
    
    /** The method that check if the desired number can be found in the list */ 
    public static boolean ifContains(int item) {
        int index = 0;
        while(index < n) {
            if(theList[index] == item) {
                return true;
            }
            index++;
        }
        return false;
    }
    
    /** The method that showed a random value in the list */
    public static int grab() {
        int i = new Random().nextInt(n);
        return theList[i];
    }
    
    /** The method that prints out the number of unique items in the list */
    public static void numItems() {
        if (n != 0) {
            int currentValue = theList[0];
            int ptr = 1; //track the next index
            int result = 1; //return the unique item
            while(ptr < n) {
                if(currentValue != theList[ptr]) {
                    result++;
                    currentValue = theList[ptr];
                }
                ptr++;
            }
            System.out.println(result);
        }
    }
}
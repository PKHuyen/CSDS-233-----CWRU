import java.util.*;

public class HashTable {
    // The field to store the array of chains
    private Node[] mapArray;

    //The field to store the current capacity of the array of chains
    private int tableSize;

    //The field to store the current size of the array of chains
    private int size;

    //The field to store the load factor of the array of chains
    private final double loadFactor = 0.75;

    /** Node class to create node in the chaining method of Hash function */
    public class Node {
        String key;
        final int hashCode; //the hashCode never change
        Node next;
        int frequency;

        /** Constructor of Node */
        public Node (String key, int hashCode) {
            this.key = key;
            this.hashCode = hashCode;
            this.frequency = 0;
        }
    }

    /**Constructor of HashTable
     * Initialize the array of chains
     * Set the capacity and size of array
     * Create empty chain
    */
    public HashTable(int capacity) {
        this.tableSize = capacity;
        this.mapArray = new Node[tableSize];
        size = 0;
    }

    /**Helper method to get the size of the array */
    public int getSize() {
        return this.size;
    }

    /** Helper method to find the hashCode result of each String */
    public static final int hashCode(String key) {
        key = key.toUpperCase();
        return Math.abs(key.hashCode());
    }

    /** Helper method to implement hash function to find the index of each key */
     public int getKeyIndex(String key) {
         int hashCode = hashCode(key); // From key convert to hashCode the use hash function
         int index = hashCode % tableSize;
         return index;
     }

    /**Helper method to get the node of the key if it's in the table*/
    public Node getNode(String key) {
        int index = 0;
        while (index < mapArray.length) {
            if (mapArray[index] == null) index++; //if there's no key in the entry of map, go to next entry
            else if (mapArray[index] != null) { //if there's a key, check if there's next node, if yes then add each to new map, else go to next entry
                if (mapArray[index].next == null) {
                    if (mapArray[index].key.equalsIgnoreCase(key)) return mapArray[index];
                    index++;
                }
                else { //If go to here then this entry have multiple nodes. Iterate from head to tail, check if it's equals to key. If yes, increase frequency
                    Node current = mapArray[index];
                    Node nextNode = mapArray[index].next;
                    while (nextNode.next != null) {
                        if (current.key.equalsIgnoreCase(key)) return current;
                        current = nextNode;
                        nextNode = current.next;
                    }
                    //If go to here, this is the last 2 nodes of this entry. Check current and last node if it's equals key. If yes, increase freuquency
                    if (current.key.equalsIgnoreCase(key)) return current;
                    current = nextNode;
                    if (current.key.equalsIgnoreCase(key)) return current;
                    index++; //Move to next entry
                }
            }
        }
        return null;
    }

    /**Helper method to search for the key in the chain and count the frequency of the key met*/
    public boolean search(String key) {
        int index = 0;
        while (index < mapArray.length) {
            if (mapArray[index] == null) index++; //if there's no key in the entry of map, go to next entry
            else if (mapArray[index] != null) { //if there's a key, check if there's next node, if yes then add each to new map, else go to next entry
                if (mapArray[index].next == null) {
                    if (mapArray[index].key.equalsIgnoreCase(key)) return true;
                    index++;
                }
                else { //If go to here then this entry have multiple nodes. Iterate from head to tail, check if it's equals to key. If yes, increase frequency
                    Node current = mapArray[index];
                    Node nextNode = mapArray[index].next;
                    while (nextNode.next != null) {
                        if (current.key.equalsIgnoreCase(key)) return true;
                        current = nextNode;
                        nextNode = current.next;
                    }
                    //If go to here, this is the last 2 nodes of this entry. Check current and last node if it's equals key. If yes, increase freuquency
                    if (current.key.equalsIgnoreCase(key)) return true;
                    current = nextNode;
                    if (current.key.equalsIgnoreCase(key)) return true;
                    index++; //Move to next entry
                }
            }
        }
        return false;
    }

    /** Helper method to add key into the array of chains */
    public void insert(String key) {
        int keyIndex = getKeyIndex(key);
        Node node = new Node(key, hashCode(key)); //create a new node that have key and hashCode of key to implement
        Node head = mapArray[keyIndex];
        if (key != "") {
            if (search(key) == true) {
                Node nodeInTable = getNode(key);
                nodeInTable.frequency++;
                return; //if key has been found in hash table, do nothing
            } 
            else { //else, increase size of map, add new node which has pointer point to head of that entry (new node becomes new head)
                size++;
                node.next = head;
                node.frequency = 1;
                mapArray[keyIndex] = node;  
            }
            if (size >= loadFactor * tableSize) rehash(); // after add, if the size overcome, rehash to avoid collisions
        }
    }

    /** Helper method to rehash */ 
    public void rehash() {
        int index = 0;
        tableSize *= 2; //set new current capacity double
        HashTable newMap = new HashTable(tableSize); // create new hash table that have new current capacity
        //Start to copy to new map
        while (index < mapArray.length) {
            if (mapArray[index] == null) index++; //if there's no key in the entry of map, go to next entry
            else if (mapArray[index] != null) { //if there's a key, check if there's next node, if yes then add each to new map, else go to next entry
                if (mapArray[index].next == null) {
                    newMap.insert(mapArray[index].key);
                    index++;
                }
                else { //If go to here, the entry have multiples nodes. Start copy and iterate all keys in old map to new map
                    Node current = mapArray[index];
                    Node nextNode = mapArray[index].next;
                    while (nextNode.next != null) {
                        newMap.insert(current.key);
                        current = nextNode;
                        nextNode = current.next;
                    }
                    newMap.insert(current.key);
                    current = nextNode;
                    newMap.insert(current.key);
                    index++;
                }
            }
        }
        this.mapArray = newMap.mapArray; //set mapArray to new map table. This also means delete old map
    }

    /** wordCount method */
    public void wordCount(String input) {
        String[] list = splitInput(input); //Function splitInput to create an array of words in the input sentence
        for (int index = 0; index < list.length; index++) {
            if (list[index] == "") return;
            insert(list[index]);
        }
        int index = 0;
        //Loop through the hash table to print out the list of words and frequencies
        while (index < mapArray.length) {
            if (mapArray[index] == null) index++; //if the entry is empty, go to next entry
            else if (mapArray[index] != null) {
                if (mapArray[index].next == null) { //If this entry only have 1 node then print out and go to the next entry
                    System.out.println("The word (" + mapArray[index].key + ") has frequency " + mapArray[index].frequency);
                    index++;
                }
                else { //If this entry have multiple nodes. Iterate and print out every node, then go to the next entry
                    Node current = mapArray[index];
                    Node nextNode = mapArray[index].next;
                    while (nextNode.next != null) {
                        System.out.println("The word (" + current.key + ") has frequency " + current.frequency);
                        current = nextNode;
                        nextNode = current.next;
                    }
                    System.out.println("The word (" + current.key + ") has frequency " + current.frequency);
                    current = nextNode;
                    System.out.println("The word (" + current.key + ") has frequency " + current.frequency);
                    index++;
                } 
            }
        }
    }

    /**Wrapper method for split method */
    public String[] splitInput(String s) {
        return s.split("\\P{Alpha}+");
    }

    public static void main (String[] args) {
        HashTable table = new HashTable(10);
        String input = "a a a b b s s a s b a s d ";
        table.wordCount(input);
    }
}
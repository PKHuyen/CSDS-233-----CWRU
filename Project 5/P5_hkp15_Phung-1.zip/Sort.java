import java.util.*;
import java.io.*;
public class Sort {

    /** Insertion Sort Algorithm to sort in descending */
    public static void insertionSort (int[] arr) {
        //From left to right, choose the current nunmber to compare with the next number
        for (int i = 1; i < arr.length; i++) {
            int toInsert = arr[i];
            int j = i - 1;
            //If the number on the right of current number is smaller than to insert number, swap 2 positions
            while (j >= 0 && arr[j] < toInsert) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = toInsert; // finish swapping
        }
    }

    /** Bubble sort Algorithm to sort in descending */
    public static void bubbleSort(int[] arr) {
        // Compare 2 number continuosly, if right side is bigger, swap 2 positions
        for (int i = 0; i < arr.length - 1; i++) { //Left side numebr
            for (int j = i + 1; j < arr.length; j++) { //Right side number
                if (arr[i] < arr[j]) { //If left side is smaller than right side 
                    int toSwap = arr[i]; // swap
                    arr[i] = arr[j];
                    arr[j] = toSwap;
                }
            }
        }
    }

    /** Shell sort using Hibbard Sort, use increment to  calculate the number of elements in eqach shell */
    // Hibbard Sort
    public static void shellSort(int[] arr) {
        int i, j;
        int temp; //temporary variable to remember the current value
        int increment = 1; //increment value of Hibbard sequence
        int k = 0; //the power of 2^k - 1 in Hibbard Sequence
        while (increment <= arr.length + 1) {
            for (i = increment; i < arr.length - 1; i++) {
                temp = arr[i];
                j = i;
                while (j >= increment && arr[j - increment] < temp) {
                    arr[j] = arr[j - increment];
                    j -= increment;
                }
                arr[j] = temp;
            }
            k++;
            increment = (int)(Math.pow(2,k)) - 1; //Hibbard's formula of shell sort incrementation
        }
    }

    /** Helper method of quick sort, the input includes array of number that needed to be sorted, index of the first element and the last element in that array */
    private static void myQuickSort(int[] arr, int first, int last) {
        int left = first;
        int mid = (last + first) / 2; //index position of pivot element
        int right = last;
        int pivot = arr[mid];
        if (first >= right) return; //base case. If go here then all array had been sorted
        while ((left < arr.length || right >= 0) && left <= right) { 
            //check and increment the index
            if (arr[left] > pivot) left++;
            else if (arr[right] < pivot) right--;
            if (left > right) return;

            // Swap elements if the left side smaller than right side
            if (arr[left] <arr[right]) {
                int toSwap = arr[left];
                arr[left] = arr[right];
                arr[left] = toSwap;
            }

            left++;
            right--;
        }   

        //Recursion to finish the array
        myQuickSort(arr, first, right);
        myQuickSort(arr, left, last);

    }

    /** Quick sort method that calls the helper method my quick sort to start sorting */
    public static void quickSort(int[] arr) {
        myQuickSort(arr, 0 , arr.length - 1);
    }

    /** Helper method to help merge all sub arrays */
    private static void merge(int[] arr, int first, int mid, int last) {
        int subArr1 =  mid - first + 1;
        int subArr2 = last - mid;
        
        // The subarrays splitted from the input array
        int[] leftArray = new int[subArr1]; 
        int[] rightArray = new int[subArr2];

        //Implement the elements to the sub array
        for (int i = 0; i < subArr1; i++) leftArray[i] = arr[first + i];
        for (int j = 0; j < subArr2; j++) rightArray[j] = arr[mid + j + 1];

        int i = 0, j = 0;
        int k = first;
        if (first > last) return; //base case, if go here then the input array is sorted

        //Start soring in the sub arrays
        while (i < subArr1 && j < subArr2) {
            if (leftArray[i] >= rightArray[j]) { //If the left side element is larger then go to the merged array first
                arr[k] = leftArray[i];
                i++;
            }
            else { //If the right side element is larger then go to the merged array first
                arr[k] = rightArray[j];
                j++;
            }
            k++;
        }
        //Add the rest of the sub arrays into the merged array
        while (i < subArr1) {
            arr[k] = leftArray[i];
            i++;
            k++;
        }
        while (j < subArr2) {
            arr[k] = rightArray[j];
            j++;
            k++;
        }
    }

    /**Helper method of mergeSort, using recursion to sort then call merge to put all sub arrays elements to sorted list */
    private static void myMergeSort(int arr[], int first, int last) {
        if (first < last) {
            int mid = (first + last) /2;
            myMergeSort(arr, first, mid);
            myMergeSort(arr, mid + 1, last);
            merge(arr, first, mid, last);
        }
    }

    /** Merge sort Algorithm to sort descending order */
    public static void mergeSort(int[] arr) {
        myMergeSort(arr, 0, arr.length - 1);
    }

    /** Helper method of upgraded Quick sort algorithm. */
    private static void myUpgradedQuickSort(int[] arr, int first, int last, int d, int k, int currentDepth) {
        //If the current depth of the "tree" reached input d, switch from quick sort to merge sort
        if (currentDepth >= d) {
            int[] newArr = Arrays.copyOfRange(arr, first, last + 1); 
            mergeSort(newArr);
            System.arraycopy(newArr, 0, arr, first, last - first + 1);
            return;
        }
        //If the current number of elements in each sub arrays reached input k, switch from quick sort to insertion sort
        if (last - first <= k) {
            int[] newArr = Arrays.copyOfRange(arr, first, last + 1);
            insertionSort(newArr);
            System.arraycopy(newArr, 0, arr, first, last - first + 1);
            return;
        }
    }

    /** UpgradedQuickSort that calls myUpgradedQuickSort helper method to sort in quick sort, merge sort, or insertion sort */
    public static void upgradedQuickSort(int[] arr, int d, int k) {
        myUpgradedQuickSort(arr, 0, arr.length, d, k, 0);
    }

    /** Create a random array that have n elements */
    public static int[] generateRandomArray(int n) {
        Random r = new Random();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = r.nextInt(n);
        }
        return arr;
    }
    
    /** Helper method to help readCommands method to convert array of number into integer */
    private static int[] stringToInt(String[] arr) {
        int[] newArr = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            newArr[i] = Integer.parseInt(arr[i]);            
        }
        return newArr;
    }
    

        /** Read Commands method. Read the filepath, go to the file and read the contents, print out the results*/
    public static void readCommands(String filePath) throws IOException{
        BufferedReader read = new BufferedReader(new FileReader(filePath));
        String[] arrayOfStrings = new String[12]; 
        StringBuilder b = new StringBuilder();
        while (read.ready()) { //When the current line had been read, go to next line, if there's content, continue
            arrayOfStrings = read.readLine().split(" "); //Separate the name of sort and the array that needed to be sorted

            //Because upgraded Quick sort had a different syntax in commands.txt, had to put in special case
            if (arrayOfStrings[0].equals("upgradedQuickSort:")) {
                b.append(arrayOfStrings[0] + " "); // Copy the name of method
                String[] tempSubstring = arrayOfStrings[4].substring(1, arrayOfStrings[4].length() - 1).split(",");
                int[] tempInt = stringToInt(tempSubstring);
                insertionSort(tempInt); //Sort
                b.append(Arrays.toString(tempInt).replace(" ", ""));
                b.append("\n");
            }
                
            //Other cases
            else {
                if (arrayOfStrings[0].isEmpty()) continue; //If there's an empty string, do nothing
                else {
                    b.append(arrayOfStrings[0] + " ");
                    String[] tempSubstring = arrayOfStrings[1].substring(1, arrayOfStrings[1].length() - 1).split(",");
                    int[] tempInt = stringToInt(tempSubstring);
                    insertionSort(tempInt);
                    b.append(Arrays.toString(tempInt).replace(" ", ""));
                    b.append("\n");
                }
            }
        }
        System.out.println(b.toString());
    }                

    /** Main method to run the program */
    public static void main (String[] args) throws IOException {
        int[] arr = generateRandomArray(10);
        insertionSort(arr);
        bubbleSort(arr);
        shellSort(arr);
        quickSort(arr);
        mergeSort(arr);
        upgradedQuickSort(arr, 2, 2);
        readCommands("C:/Users/sjdfi/Downloads/commands.txt");
    }
}

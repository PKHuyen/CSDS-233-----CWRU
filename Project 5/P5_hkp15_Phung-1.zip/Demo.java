import java.util.*; 
public class Demo extends Sort { 
    //The field that remembered random arrays with different size
    private static int[] arrayList;

    /** Helper method to halp benchmark with all number of elements */
    private static void benchmarking(String sortType) { 
        int[] size = new int[] {10, 20, 50, 100, 200, 500, 1000, 2000, 5000}; //Array of size of the array that needed to be sorted
        int iterations = 100; 
        long sort = 0; //time to sort

        // Create different arrays list that have dirrent size and put in to another array. (Array in array)
        for (int i = 0; i < size.length; i++) { 
            int sizeArr = size[i]; 
            List<int[]> randomArray = new ArrayList<>(iterations); 
            for (int j = 0; j < iterations; j++) { 
                randomArray.add(generateRandomArray(sizeArr)); 
                arrayList = randomArray.get(j); 
            } 

            long initial = System.nanoTime(); //Declare initial time when start to sort
            for (int[] arr : randomArray) { 
                initial = System.nanoTime(); 
                if (sortType.equalsIgnoreCase("insertionSort")) insertionSort(arr); 
                else if (sortType.equalsIgnoreCase("bubbleSort")) bubbleSort(arr); 
                else if (sortType.equalsIgnoreCase("shellShort")) shellSort(arr); 
                else if (sortType.equalsIgnoreCase("quickSort")) quickSort(arr); 
                else if (sortType.equalsIgnoreCase("mergeSort")) mergeSort(arr); 
                else if (sortType.equalsIgnoreCase("upgradedQuickSort")) upgradedQuickSort(arr, 2, 3); 
            } 
            sort = (System.nanoTime() - initial); //Total time
            System.out.println("The time to sort random array: "  + sort + " when the size is " + size[i]); 
            
            /**Running time of sorted array */
            for (int[] arr : randomArray) {
                upgradedQuickSort(arr, 2, 3); //Sort the random array
                initial = System.nanoTime(); //Start to time
                if (sortType.equalsIgnoreCase("insertionSort")) insertionSort(arr); 
                else if (sortType.equalsIgnoreCase("bubbleSort")) bubbleSort(arr); 
                else if (sortType.equalsIgnoreCase("shellShort")) shellSort(arr); 
                else if (sortType.equalsIgnoreCase("quickSort")) quickSort(arr); 
                else if (sortType.equalsIgnoreCase("mergeSort")) mergeSort(arr); 
                else if (sortType.equalsIgnoreCase("upgradedQuickSort")) upgradedQuickSort(arr, 2, 3); 
            } 
            sort = (System.nanoTime() - initial); //Total time
            System.out.println("The time to sort sorted array: "  + sort + " when the size is " + size[i]); 
        
            //Running time of reverse sorted array
            for (int[] arr : randomArray) {
                Arrays.sort(arr); //Sort method of Arrays API that go ascending.
                initial = System.nanoTime(); //Start to time
                if (sortType.equalsIgnoreCase("insertionSort")) insertionSort(arr); 
                else if (sortType.equalsIgnoreCase("bubbleSort")) bubbleSort(arr); 
                else if (sortType.equalsIgnoreCase("shellShort")) shellSort(arr); 
                else if (sortType.equalsIgnoreCase("quickSort")) quickSort(arr); 
                else if (sortType.equalsIgnoreCase("mergeSort")) mergeSort(arr); 
                else if (sortType.equalsIgnoreCase("upgradedQuickSort")) upgradedQuickSort(arr, 2, 3); 
            } 
            sort = (System.nanoTime() - initial); //Total time
            System.out.println("The time to sort reverse sorted array: "  + sort + " when the size is " + size[i]);
            System.out.println();
        } 
    } 

    /** Main method to show all running time in order to write benchmarking */
    public static void main (String[] args) { 
        benchmarking("insertionSort"); 
        benchmarking("bubbleSort");
        benchmarking("shellSort");
        benchmarking("quickSort");
        benchmarking("mergeSort");
        benchmarking("upgradedQuickSort");
    } 
}